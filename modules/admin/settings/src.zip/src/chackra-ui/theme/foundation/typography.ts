import { theme as chakraTheme } from "@chakra-ui/react";

const typography = {
  fontWeights: {
    ...chakraTheme.fontWeights,
    normal: 500,
    bold: 600,
  },
  fonts: {
    ...chakraTheme.fonts,
  },
  fontSizes: {
    ...chakraTheme.fontSizes,
  },
};

export default typography;
