import { Box, Flex, Text, VStack } from "@chakra-ui/react";
import "./style/global.css";

function App() {
  return (
    <>
      <Box>
        <Text className="theme-font">This is the Header</Text>
      </Box>
      <Flex w="100%" h="100%">
        <VStack bg="red">
          <Box h="200px">fuck</Box>
        </VStack>
        <VStack bg="blue"></VStack>
        <VStack bg="green"></VStack>
      </Flex>
    </>
  );
}
export default App;
