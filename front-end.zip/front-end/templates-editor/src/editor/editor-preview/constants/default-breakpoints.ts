const DEFAULT_BREAKPOINTS = {
  sm: "480px",
  md: "768px",
  lg: "1280px",
};

export default DEFAULT_BREAKPOINTS;
