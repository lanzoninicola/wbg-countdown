import { Button } from "@chakra-ui/react";
import { useRef, useState } from "react";

import PropertyWrapper from "../../layout/property-wrapper/property-wrapper";
import DialogWrapper from "../../primitives/dialog-wrapper/dialog-wrapper";
import FontFamilyPicker from "../../primitives/font-family-picker/font-family-picker";
import Label from "../../primitives/label/label";

interface FontFamilyProps {
  label: string;
  fontFamily: string;
  fontWeight: string;
  onSelectFontFamily: (fontFamily: string) => void;
  onSelectFontWeight: (fontWeight: string) => void;
}

export default function FontFamily({
  label,
  fontFamily,
  fontWeight,
  onSelectFontFamily,
  onSelectFontWeight,
}: FontFamilyProps) {
  const [pickerFontFamily, setPickerFontFamily] = useState<string>(fontFamily);
  const [pickerFontWeight, setPickerFontWeight] = useState<string>(fontWeight);
  const [showDialog, setShowDialog] = useState(false);
  let ref = useRef(null);

  const onCloseDialog = () => {
    // Update the global state
    onSelectFontFamily(pickerFontFamily);

    // if enable this the font family above will not update. Need to figure out why
    // onSelectFontWeight(pickerFontWeight);

    setShowDialog(!showDialog);
  };

  return (
    <PropertyWrapper>
      <Label>{label}</Label>
      <Button
        ref={ref}
        gridColumn={"2 / -1"}
        size="xs"
        className="theme-font"
        onClick={() => setShowDialog(!showDialog)}
        lineHeight="1"
      >
        {fontFamily ? `${fontFamily} (${fontWeight})` : "Select font"}
      </Button>
      {showDialog && (
        <DialogWrapper callerRef={ref} onCloseDialog={onCloseDialog}>
          <FontFamilyPicker
            fontFamily={pickerFontFamily}
            fontWeight={pickerFontWeight}
            onSelectFontFamily={setPickerFontFamily}
            onSelectFontWeight={setPickerFontWeight}
          />
        </DialogWrapper>
      )}
    </PropertyWrapper>
  );
}
