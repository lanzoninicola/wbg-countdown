import findById from "./find-by-id";
import create from "./create";
import update from "./update";
import remove from "./remove";

export { findById, create, update, remove };
