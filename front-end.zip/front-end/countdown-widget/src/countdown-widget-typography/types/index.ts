export interface Typography {
  fontFamily: string;
  fontWeight: string;
}
